//
//  CheckBalanceViewController.h
//  SmsDemo
//
//  Created by elliotyuan on 13-4-3.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckBalanceViewController : UIViewController{
    UITextField *userName;
    UITextField *password;
    UITextView  *responseMsg;
}

- (IBAction)onSendButtonPressed: (id)sender;

@property (nonatomic, retain) IBOutlet UITextField *userName;
@property (nonatomic, retain) IBOutlet UITextField *password;
@property (nonatomic, retain) IBOutlet UITextView *responseMsg;

@end
