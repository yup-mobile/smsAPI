//
//  GetReplyByTimeViewController.m
//  SmsDemo
//
//  Created by elliotyuan on 13-4-3.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import "GetReplyByTimeViewController.h"
#import "SmsClient.h"

@interface GetReplyByTimeViewController ()

@end

@implementation GetReplyByTimeViewController

@synthesize phoneNum;
@synthesize startTime;
@synthesize endTime;
@synthesize responseMsg;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onSendButtonPressed: (id)sender;{
    NSString *sPhoneNum = [[NSString alloc] initWithString:phoneNum.text];
    NSString *sStartTime = [[NSString alloc] initWithString:startTime.text];
    NSString *sEndTime = [[NSString alloc] initWithString:endTime.text];
    SmsClient *smsClient = [[SmsClient alloc] init];
    
    NSString *response = [smsClient getReplyByTime:@"zhengyp" password:@"aca3955f5c65c2f4be6c2bf8a2c956d2" phoneNum: sPhoneNum extNum: @"" startTime:sStartTime endTime: sEndTime offset:@"0" mr:@"500"];
    NSLog(@"response: %@", response);
    responseMsg.text = response;
    
}

-(void)viewTapped:(UITapGestureRecognizer*)tapGr{
    [phoneNum resignFirstResponder];
    [startTime resignFirstResponder];
    [endTime resignFirstResponder];
    
    
}


@end
