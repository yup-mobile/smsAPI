//
//  GetStatusByIdViewController.h
//  SmsDemo
//
//  Created by elliotyuan on 13-4-2.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetStatusByIdViewController : UIViewController{
    
    UITextField *messageID;
    UITextView  *responseMsg;
    
}
- (IBAction)onSendButtonPressed: (id)sender;

@property (nonatomic, retain) IBOutlet UITextField *messageID;
@property (nonatomic, retain) IBOutlet UITextView *responseMsg;

@end
