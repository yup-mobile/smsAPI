//
//  ViewController.m
//  SmsDemo
//
//  Created by elliotyuan on 13-3-30.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import "ViewController.h"
#import "SendSMSViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UITableViewDataSource

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        cell= [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault
                                   reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    switch (indexPath.row)
	{
		case 0:
		{
            cell.textLabel.text=@"发送短消息";
            break;
		}
		case 1:
		{
            
            cell.textLabel.text=@"话题2";
            break;
		}
		
	}

    
    return cell;
}

#pragma mark -
#pragma mark UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *anotherViewController;
    switch (indexPath.row)
	{
		case 0:
		{

            anotherViewController = [[SendSMSViewController alloc] init];
            [self.navigationController pushViewController:anotherViewController animated:YES];
            break;
		}
		case 1:
		{
            
            break;
		}
            
	}

    }

@end
