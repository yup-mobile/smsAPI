//
//  GetReplyByTimeViewController.h
//  SmsDemo
//
//  Created by elliotyuan on 13-4-3.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetReplyByTimeViewController : UIViewController{
    UITextField *phoneNum;
    UITextField *startTime;
    UITextField *endTime;
    UITextView  *responseMsg;
}

- (IBAction)onSendButtonPressed: (id)sender;

@property (nonatomic, retain) IBOutlet UITextField *phoneNum;
@property (nonatomic, retain) IBOutlet UITextField *startTime;
@property (nonatomic, retain) IBOutlet UITextField *endTime;
@property (nonatomic, retain) IBOutlet UITextView *responseMsg;

@end
