//
//  SendSMSViewController.m
//  SmsDemo
//
//  Created by elliotyuan on 13-3-30.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import "SendSMSViewController.h"
#import "SmsClient.h"

@interface SendSMSViewController ()

@end

@implementation SendSMSViewController

@synthesize toPhone;
@synthesize toMessage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onSendButtonPressed: (id)sender;{
    NSString *sToPhone = [[NSString alloc] initWithString:toPhone.text];
    NSString *sToMessage = [[NSString alloc] initWithString:toMessage.text];
	//UIAlertView *alert = [[UIAlertView alloc] initWithTitle:sToPhone message:sToMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    //[alert show];
    
    SmsClient *smsClient = [[SmsClient alloc] init];
    
    NSString *response = [smsClient sendSms:@"zhengyp" password:@"aca3955f5c65c2f4be6c2bf8a2c956d2" message: sToMessage target:sToPhone ext:@"" send_time:@""];
    /*
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"http://114.80.200.100:8081/axis2/services/yc.ycHttpSoap11Endpoint/"]];
    [request addValue:@"text/xml; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
	[request setHTTPMethod: @"POST"];

    NSString *post = @"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:yc=\"http://yc\" xmlns:xsd=\"http://yc/xsd\"> <soapenv:Header/>"
    "<soapenv:Body>"
    "<yc:sendsms>"
    "<yc:username>"
        "zhengyp"
    "</yc:username>"
    "<yc:password>"
        "aca3955f5c65c2f4be6c2bf8a2c956d2"
    "</yc:password>"
    "<yc:_SendRequset>"
    "<xsd:ext>"
    "</xsd:ext>"
    "<xsd:message>";
        post = [post stringByAppendingString: sToMessage];
        post = [post stringByAppendingString:
    @"</xsd:message>"
    "<xsd:send_time>"
    "</xsd:send_time>"
    "<xsd:target>"];
        post = [post stringByAppendingString: sToPhone];
        post = [post stringByAppendingString:
    @"</xsd:target>"
    "</yc:_SendRequset>"
    "</yc:sendsms>"
    "</soapenv:Body>"
    "</soapenv:Envelope>"];
    NSLog(@"post=%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
	[request setHTTPBody:postData];
    NSError *error = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
    if (data == nil) {
        NSLog(@"send request failed: %@", error);
    }
    NSString *response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"response: %@", response);
 	*/
    NSLog(@"response: %@", response);
}


//
-(void)viewTapped:(UITapGestureRecognizer*)tapGr{
    [toPhone resignFirstResponder];
    [toMessage resignFirstResponder];
}

@end
