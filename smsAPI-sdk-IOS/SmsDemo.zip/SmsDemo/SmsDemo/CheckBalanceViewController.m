//
//  CheckBalanceViewController.m
//  SmsDemo
//
//  Created by elliotyuan on 13-4-3.
//  Copyright (c) 2013年 elliotyuan. All rights reserved.
//

#import "CheckBalanceViewController.h"
#import "SmsClient.h"

@interface CheckBalanceViewController ()

@end

@implementation CheckBalanceViewController

@synthesize userName;
@synthesize password;
@synthesize responseMsg;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onSendButtonPressed: (id)sender;{
    NSString *sUserName = [[NSString alloc] initWithString:userName.text];
    NSString *sPassword = [[NSString alloc] initWithString:password.text];
    SmsClient *smsClient = [[SmsClient alloc] init];
    
    NSString *response = [smsClient checkBalance: sUserName password:sPassword];
    NSLog(@"response: %@", response);
    responseMsg.text = response;
    
}


-(void)viewTapped:(UITapGestureRecognizer*)tapGr{
    [userName resignFirstResponder];
    [password resignFirstResponder];
        
    
}

@end
